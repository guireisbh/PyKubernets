kubernetes.client.api.discovery\_v1\_api module
===============================================

.. automodule:: kubernetes.client.api.discovery_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
