kubernetes.client.models.v1\_priority\_class\_list module
=========================================================

.. automodule:: kubernetes.client.models.v1_priority_class_list
   :members:
   :undoc-members:
   :show-inheritance:
