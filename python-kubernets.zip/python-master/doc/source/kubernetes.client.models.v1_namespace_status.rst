kubernetes.client.models.v1\_namespace\_status module
=====================================================

.. automodule:: kubernetes.client.models.v1_namespace_status
   :members:
   :undoc-members:
   :show-inheritance:
