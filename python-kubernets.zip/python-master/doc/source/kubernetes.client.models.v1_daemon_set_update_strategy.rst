kubernetes.client.models.v1\_daemon\_set\_update\_strategy module
=================================================================

.. automodule:: kubernetes.client.models.v1_daemon_set_update_strategy
   :members:
   :undoc-members:
   :show-inheritance:
