kubernetes.client.api.apis\_api module
======================================

.. automodule:: kubernetes.client.api.apis_api
   :members:
   :undoc-members:
   :show-inheritance:
