kubernetes.client.models.v1\_aggregation\_rule module
=====================================================

.. automodule:: kubernetes.client.models.v1_aggregation_rule
   :members:
   :undoc-members:
   :show-inheritance:
