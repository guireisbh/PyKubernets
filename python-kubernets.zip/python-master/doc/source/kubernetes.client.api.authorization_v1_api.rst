kubernetes.client.api.authorization\_v1\_api module
===================================================

.. automodule:: kubernetes.client.api.authorization_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
