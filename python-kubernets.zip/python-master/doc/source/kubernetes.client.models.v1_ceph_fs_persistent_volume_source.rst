kubernetes.client.models.v1\_ceph\_fs\_persistent\_volume\_source module
========================================================================

.. automodule:: kubernetes.client.models.v1_ceph_fs_persistent_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
