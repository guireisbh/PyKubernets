kubernetes.client.models.v1\_cluster\_role\_binding\_list module
================================================================

.. automodule:: kubernetes.client.models.v1_cluster_role_binding_list
   :members:
   :undoc-members:
   :show-inheritance:
