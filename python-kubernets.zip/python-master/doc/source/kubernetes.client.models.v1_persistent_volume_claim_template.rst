kubernetes.client.models.v1\_persistent\_volume\_claim\_template module
=======================================================================

.. automodule:: kubernetes.client.models.v1_persistent_volume_claim_template
   :members:
   :undoc-members:
   :show-inheritance:
