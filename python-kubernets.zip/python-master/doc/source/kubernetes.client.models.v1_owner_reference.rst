kubernetes.client.models.v1\_owner\_reference module
====================================================

.. automodule:: kubernetes.client.models.v1_owner_reference
   :members:
   :undoc-members:
   :show-inheritance:
