kubernetes.client.models.v1\_node\_daemon\_endpoints module
===========================================================

.. automodule:: kubernetes.client.models.v1_node_daemon_endpoints
   :members:
   :undoc-members:
   :show-inheritance:
