kubernetes.client.models.v1\_ephemeral\_container module
========================================================

.. automodule:: kubernetes.client.models.v1_ephemeral_container
   :members:
   :undoc-members:
   :show-inheritance:
