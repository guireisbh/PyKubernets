kubernetes.client.models.v1\_azure\_disk\_volume\_source module
===============================================================

.. automodule:: kubernetes.client.models.v1_azure_disk_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
