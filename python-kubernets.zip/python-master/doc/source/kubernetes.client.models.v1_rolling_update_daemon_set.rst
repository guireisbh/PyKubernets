kubernetes.client.models.v1\_rolling\_update\_daemon\_set module
================================================================

.. automodule:: kubernetes.client.models.v1_rolling_update_daemon_set
   :members:
   :undoc-members:
   :show-inheritance:
