kubernetes.client.models.v1\_match\_resources module
====================================================

.. automodule:: kubernetes.client.models.v1_match_resources
   :members:
   :undoc-members:
   :show-inheritance:
