kubernetes.client.models.v1\_endpoint\_address module
=====================================================

.. automodule:: kubernetes.client.models.v1_endpoint_address
   :members:
   :undoc-members:
   :show-inheritance:
