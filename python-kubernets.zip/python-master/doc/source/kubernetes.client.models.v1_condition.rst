kubernetes.client.models.v1\_condition module
=============================================

.. automodule:: kubernetes.client.models.v1_condition
   :members:
   :undoc-members:
   :show-inheritance:
