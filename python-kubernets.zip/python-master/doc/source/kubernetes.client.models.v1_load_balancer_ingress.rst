kubernetes.client.models.v1\_load\_balancer\_ingress module
===========================================================

.. automodule:: kubernetes.client.models.v1_load_balancer_ingress
   :members:
   :undoc-members:
   :show-inheritance:
