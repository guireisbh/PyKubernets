kubernetes.client.models.v1\_network\_policy\_port module
=========================================================

.. automodule:: kubernetes.client.models.v1_network_policy_port
   :members:
   :undoc-members:
   :show-inheritance:
