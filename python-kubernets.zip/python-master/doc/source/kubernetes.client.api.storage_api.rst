kubernetes.client.api.storage\_api module
=========================================

.. automodule:: kubernetes.client.api.storage_api
   :members:
   :undoc-members:
   :show-inheritance:
