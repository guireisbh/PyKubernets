kubernetes.client.models.v1\_pod\_disruption\_budget\_spec module
=================================================================

.. automodule:: kubernetes.client.models.v1_pod_disruption_budget_spec
   :members:
   :undoc-members:
   :show-inheritance:
