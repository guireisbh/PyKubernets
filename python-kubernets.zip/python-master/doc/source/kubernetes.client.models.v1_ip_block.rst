kubernetes.client.models.v1\_ip\_block module
=============================================

.. automodule:: kubernetes.client.models.v1_ip_block
   :members:
   :undoc-members:
   :show-inheritance:
