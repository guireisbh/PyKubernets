kubernetes.client.models.v1\_persistent\_volume\_claim module
=============================================================

.. automodule:: kubernetes.client.models.v1_persistent_volume_claim
   :members:
   :undoc-members:
   :show-inheritance:
