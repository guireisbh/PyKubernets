kubernetes.client.models.core\_v1\_event module
===============================================

.. automodule:: kubernetes.client.models.core_v1_event
   :members:
   :undoc-members:
   :show-inheritance:
