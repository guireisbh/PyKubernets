kubernetes.client.models.v1\_endpoint\_conditions module
========================================================

.. automodule:: kubernetes.client.models.v1_endpoint_conditions
   :members:
   :undoc-members:
   :show-inheritance:
