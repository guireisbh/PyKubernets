kubernetes.client.api.resource\_v1alpha2\_api module
====================================================

.. automodule:: kubernetes.client.api.resource_v1alpha2_api
   :members:
   :undoc-members:
   :show-inheritance:
