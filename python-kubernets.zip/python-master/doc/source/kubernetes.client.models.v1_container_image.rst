kubernetes.client.models.v1\_container\_image module
====================================================

.. automodule:: kubernetes.client.models.v1_container_image
   :members:
   :undoc-members:
   :show-inheritance:
