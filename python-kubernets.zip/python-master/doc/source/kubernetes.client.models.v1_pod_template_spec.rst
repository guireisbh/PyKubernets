kubernetes.client.models.v1\_pod\_template\_spec module
=======================================================

.. automodule:: kubernetes.client.models.v1_pod_template_spec
   :members:
   :undoc-members:
   :show-inheritance:
