kubernetes.client.models.v1\_role\_list module
==============================================

.. automodule:: kubernetes.client.models.v1_role_list
   :members:
   :undoc-members:
   :show-inheritance:
