kubernetes.client.models.v1\_pod\_template\_list module
=======================================================

.. automodule:: kubernetes.client.models.v1_pod_template_list
   :members:
   :undoc-members:
   :show-inheritance:
