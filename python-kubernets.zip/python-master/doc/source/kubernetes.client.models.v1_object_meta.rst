kubernetes.client.models.v1\_object\_meta module
================================================

.. automodule:: kubernetes.client.models.v1_object_meta
   :members:
   :undoc-members:
   :show-inheritance:
