kubernetes.client.models.v1\_downward\_api\_volume\_file module
===============================================================

.. automodule:: kubernetes.client.models.v1_downward_api_volume_file
   :members:
   :undoc-members:
   :show-inheritance:
