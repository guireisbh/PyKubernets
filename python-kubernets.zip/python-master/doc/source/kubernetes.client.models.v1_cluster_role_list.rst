kubernetes.client.models.v1\_cluster\_role\_list module
=======================================================

.. automodule:: kubernetes.client.models.v1_cluster_role_list
   :members:
   :undoc-members:
   :show-inheritance:
