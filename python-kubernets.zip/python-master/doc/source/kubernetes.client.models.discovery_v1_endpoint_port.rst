kubernetes.client.models.discovery\_v1\_endpoint\_port module
=============================================================

.. automodule:: kubernetes.client.models.discovery_v1_endpoint_port
   :members:
   :undoc-members:
   :show-inheritance:
