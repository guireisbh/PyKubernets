kubernetes.client.models.v1\_custom\_resource\_definition\_status module
========================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_definition_status
   :members:
   :undoc-members:
   :show-inheritance:
