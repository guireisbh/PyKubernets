kubernetes.client.models.v1\_ephemeral\_volume\_source module
=============================================================

.. automodule:: kubernetes.client.models.v1_ephemeral_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
