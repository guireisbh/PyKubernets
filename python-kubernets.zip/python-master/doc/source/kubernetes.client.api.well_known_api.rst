kubernetes.client.api.well\_known\_api module
=============================================

.. automodule:: kubernetes.client.api.well_known_api
   :members:
   :undoc-members:
   :show-inheritance:
