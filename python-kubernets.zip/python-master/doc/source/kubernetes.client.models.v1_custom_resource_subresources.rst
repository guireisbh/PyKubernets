kubernetes.client.models.v1\_custom\_resource\_subresources module
==================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_subresources
   :members:
   :undoc-members:
   :show-inheritance:
