kubernetes.client.models.v1\_resource\_claim module
===================================================

.. automodule:: kubernetes.client.models.v1_resource_claim
   :members:
   :undoc-members:
   :show-inheritance:
