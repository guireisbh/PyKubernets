kubernetes.client.models.v1\_limit\_range module
================================================

.. automodule:: kubernetes.client.models.v1_limit_range
   :members:
   :undoc-members:
   :show-inheritance:
