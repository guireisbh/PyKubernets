kubernetes.client.models.v1\_azure\_file\_persistent\_volume\_source module
===========================================================================

.. automodule:: kubernetes.client.models.v1_azure_file_persistent_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
