kubernetes.client.models.v1\_custom\_resource\_validation module
================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_validation
   :members:
   :undoc-members:
   :show-inheritance:
