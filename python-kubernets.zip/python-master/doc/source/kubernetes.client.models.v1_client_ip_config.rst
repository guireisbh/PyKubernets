kubernetes.client.models.v1\_client\_ip\_config module
======================================================

.. automodule:: kubernetes.client.models.v1_client_ip_config
   :members:
   :undoc-members:
   :show-inheritance:
