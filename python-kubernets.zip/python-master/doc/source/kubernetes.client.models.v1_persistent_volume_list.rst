kubernetes.client.models.v1\_persistent\_volume\_list module
============================================================

.. automodule:: kubernetes.client.models.v1_persistent_volume_list
   :members:
   :undoc-members:
   :show-inheritance:
