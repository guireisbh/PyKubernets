kubernetes.client.models.v1\_deployment\_spec module
====================================================

.. automodule:: kubernetes.client.models.v1_deployment_spec
   :members:
   :undoc-members:
   :show-inheritance:
