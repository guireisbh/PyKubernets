kubernetes.client.models.v1\_node\_selector\_requirement module
===============================================================

.. automodule:: kubernetes.client.models.v1_node_selector_requirement
   :members:
   :undoc-members:
   :show-inheritance:
