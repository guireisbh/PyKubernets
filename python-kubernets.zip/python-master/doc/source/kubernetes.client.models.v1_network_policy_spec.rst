kubernetes.client.models.v1\_network\_policy\_spec module
=========================================================

.. automodule:: kubernetes.client.models.v1_network_policy_spec
   :members:
   :undoc-members:
   :show-inheritance:
