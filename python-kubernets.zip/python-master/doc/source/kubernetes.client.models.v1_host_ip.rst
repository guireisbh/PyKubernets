kubernetes.client.models.v1\_host\_ip module
============================================

.. automodule:: kubernetes.client.models.v1_host_ip
   :members:
   :undoc-members:
   :show-inheritance:
