kubernetes.client.models.v1\_namespace\_list module
===================================================

.. automodule:: kubernetes.client.models.v1_namespace_list
   :members:
   :undoc-members:
   :show-inheritance:
