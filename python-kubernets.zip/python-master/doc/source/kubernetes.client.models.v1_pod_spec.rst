kubernetes.client.models.v1\_pod\_spec module
=============================================

.. automodule:: kubernetes.client.models.v1_pod_spec
   :members:
   :undoc-members:
   :show-inheritance:
