kubernetes.client.models.v1\_custom\_resource\_definition\_names module
=======================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_definition_names
   :members:
   :undoc-members:
   :show-inheritance:
