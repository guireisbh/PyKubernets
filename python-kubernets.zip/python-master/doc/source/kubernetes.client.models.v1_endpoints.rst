kubernetes.client.models.v1\_endpoints module
=============================================

.. automodule:: kubernetes.client.models.v1_endpoints
   :members:
   :undoc-members:
   :show-inheritance:
