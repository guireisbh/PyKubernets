kubernetes.client.models.v1\_cross\_version\_object\_reference module
=====================================================================

.. automodule:: kubernetes.client.models.v1_cross_version_object_reference
   :members:
   :undoc-members:
   :show-inheritance:
