kubernetes.client.models.v1\_policy\_rules\_with\_subjects module
=================================================================

.. automodule:: kubernetes.client.models.v1_policy_rules_with_subjects
   :members:
   :undoc-members:
   :show-inheritance:
