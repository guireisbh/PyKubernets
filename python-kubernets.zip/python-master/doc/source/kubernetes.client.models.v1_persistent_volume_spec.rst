kubernetes.client.models.v1\_persistent\_volume\_spec module
============================================================

.. automodule:: kubernetes.client.models.v1_persistent_volume_spec
   :members:
   :undoc-members:
   :show-inheritance:
