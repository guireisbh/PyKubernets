kubernetes.client.models.v1\_pod module
=======================================

.. automodule:: kubernetes.client.models.v1_pod
   :members:
   :undoc-members:
   :show-inheritance:
