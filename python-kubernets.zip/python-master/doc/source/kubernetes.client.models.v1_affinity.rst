kubernetes.client.models.v1\_affinity module
============================================

.. automodule:: kubernetes.client.models.v1_affinity
   :members:
   :undoc-members:
   :show-inheritance:
