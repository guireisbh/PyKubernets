kubernetes.client.models.v1\_stateful\_set module
=================================================

.. automodule:: kubernetes.client.models.v1_stateful_set
   :members:
   :undoc-members:
   :show-inheritance:
