kubernetes.client.api.apiextensions\_api module
===============================================

.. automodule:: kubernetes.client.api.apiextensions_api
   :members:
   :undoc-members:
   :show-inheritance:
