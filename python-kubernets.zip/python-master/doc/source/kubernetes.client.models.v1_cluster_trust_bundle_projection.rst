kubernetes.client.models.v1\_cluster\_trust\_bundle\_projection module
======================================================================

.. automodule:: kubernetes.client.models.v1_cluster_trust_bundle_projection
   :members:
   :undoc-members:
   :show-inheritance:
