kubernetes.client.models.v1\_resource\_quota\_list module
=========================================================

.. automodule:: kubernetes.client.models.v1_resource_quota_list
   :members:
   :undoc-members:
   :show-inheritance:
