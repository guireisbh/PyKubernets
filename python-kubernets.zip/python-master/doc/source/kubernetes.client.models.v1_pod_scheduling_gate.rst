kubernetes.client.models.v1\_pod\_scheduling\_gate module
=========================================================

.. automodule:: kubernetes.client.models.v1_pod_scheduling_gate
   :members:
   :undoc-members:
   :show-inheritance:
