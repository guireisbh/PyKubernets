kubernetes.client.models.v1\_namespace\_condition module
========================================================

.. automodule:: kubernetes.client.models.v1_namespace_condition
   :members:
   :undoc-members:
   :show-inheritance:
