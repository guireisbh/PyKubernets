kubernetes.client.models.v1\_resource\_rule module
==================================================

.. automodule:: kubernetes.client.models.v1_resource_rule
   :members:
   :undoc-members:
   :show-inheritance:
