kubernetes.client.models.v1\_stateful\_set\_status module
=========================================================

.. automodule:: kubernetes.client.models.v1_stateful_set_status
   :members:
   :undoc-members:
   :show-inheritance:
