kubernetes.client.models.v1\_config\_map module
===============================================

.. automodule:: kubernetes.client.models.v1_config_map
   :members:
   :undoc-members:
   :show-inheritance:
