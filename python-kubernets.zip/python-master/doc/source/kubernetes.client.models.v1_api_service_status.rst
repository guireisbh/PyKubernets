kubernetes.client.models.v1\_api\_service\_status module
========================================================

.. automodule:: kubernetes.client.models.v1_api_service_status
   :members:
   :undoc-members:
   :show-inheritance:
