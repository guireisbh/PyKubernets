kubernetes.client.models.v1\_job\_spec module
=============================================

.. automodule:: kubernetes.client.models.v1_job_spec
   :members:
   :undoc-members:
   :show-inheritance:
