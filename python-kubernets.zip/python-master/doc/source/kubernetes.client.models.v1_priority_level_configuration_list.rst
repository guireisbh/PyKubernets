kubernetes.client.models.v1\_priority\_level\_configuration\_list module
========================================================================

.. automodule:: kubernetes.client.models.v1_priority_level_configuration_list
   :members:
   :undoc-members:
   :show-inheritance:
