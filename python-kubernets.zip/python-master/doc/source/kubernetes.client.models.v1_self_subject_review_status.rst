kubernetes.client.models.v1\_self\_subject\_review\_status module
=================================================================

.. automodule:: kubernetes.client.models.v1_self_subject_review_status
   :members:
   :undoc-members:
   :show-inheritance:
