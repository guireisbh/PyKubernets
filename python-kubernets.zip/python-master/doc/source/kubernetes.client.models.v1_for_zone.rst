kubernetes.client.models.v1\_for\_zone module
=============================================

.. automodule:: kubernetes.client.models.v1_for_zone
   :members:
   :undoc-members:
   :show-inheritance:
