kubernetes.client.models.v1\_cluster\_role module
=================================================

.. automodule:: kubernetes.client.models.v1_cluster_role
   :members:
   :undoc-members:
   :show-inheritance:
