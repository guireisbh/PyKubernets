kubernetes.client.models.v1\_node module
========================================

.. automodule:: kubernetes.client.models.v1_node
   :members:
   :undoc-members:
   :show-inheritance:
