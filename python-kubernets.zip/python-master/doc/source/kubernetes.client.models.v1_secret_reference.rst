kubernetes.client.models.v1\_secret\_reference module
=====================================================

.. automodule:: kubernetes.client.models.v1_secret_reference
   :members:
   :undoc-members:
   :show-inheritance:
