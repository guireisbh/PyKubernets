kubernetes.client.models.v1\_server\_address\_by\_client\_cidr module
=====================================================================

.. automodule:: kubernetes.client.models.v1_server_address_by_client_cidr
   :members:
   :undoc-members:
   :show-inheritance:
