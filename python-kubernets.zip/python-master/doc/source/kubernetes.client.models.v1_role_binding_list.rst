kubernetes.client.models.v1\_role\_binding\_list module
=======================================================

.. automodule:: kubernetes.client.models.v1_role_binding_list
   :members:
   :undoc-members:
   :show-inheritance:
