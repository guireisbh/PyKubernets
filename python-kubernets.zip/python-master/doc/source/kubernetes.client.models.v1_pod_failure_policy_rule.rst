kubernetes.client.models.v1\_pod\_failure\_policy\_rule module
==============================================================

.. automodule:: kubernetes.client.models.v1_pod_failure_policy_rule
   :members:
   :undoc-members:
   :show-inheritance:
