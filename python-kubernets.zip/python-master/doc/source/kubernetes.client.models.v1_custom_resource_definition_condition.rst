kubernetes.client.models.v1\_custom\_resource\_definition\_condition module
===========================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_definition_condition
   :members:
   :undoc-members:
   :show-inheritance:
