kubernetes.client.models.v1\_ingress module
===========================================

.. automodule:: kubernetes.client.models.v1_ingress
   :members:
   :undoc-members:
   :show-inheritance:
