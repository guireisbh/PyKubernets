kubernetes.client.models.v1\_capabilities module
================================================

.. automodule:: kubernetes.client.models.v1_capabilities
   :members:
   :undoc-members:
   :show-inheritance:
