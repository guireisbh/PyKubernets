kubernetes.client.models.v1\_mutating\_webhook\_configuration module
====================================================================

.. automodule:: kubernetes.client.models.v1_mutating_webhook_configuration
   :members:
   :undoc-members:
   :show-inheritance:
