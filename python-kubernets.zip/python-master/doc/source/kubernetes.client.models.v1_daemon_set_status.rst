kubernetes.client.models.v1\_daemon\_set\_status module
=======================================================

.. automodule:: kubernetes.client.models.v1_daemon_set_status
   :members:
   :undoc-members:
   :show-inheritance:
