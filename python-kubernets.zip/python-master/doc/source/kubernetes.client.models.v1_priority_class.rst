kubernetes.client.models.v1\_priority\_class module
===================================================

.. automodule:: kubernetes.client.models.v1_priority_class
   :members:
   :undoc-members:
   :show-inheritance:
