kubernetes.client.api.scheduling\_api module
============================================

.. automodule:: kubernetes.client.api.scheduling_api
   :members:
   :undoc-members:
   :show-inheritance:
