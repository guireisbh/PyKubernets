kubernetes.client.models.v1\_host\_alias module
===============================================

.. automodule:: kubernetes.client.models.v1_host_alias
   :members:
   :undoc-members:
   :show-inheritance:
