kubernetes.client.api.authentication\_v1beta1\_api module
=========================================================

.. automodule:: kubernetes.client.api.authentication_v1beta1_api
   :members:
   :undoc-members:
   :show-inheritance:
