kubernetes.client.models.v1\_endpoints\_list module
===================================================

.. automodule:: kubernetes.client.models.v1_endpoints_list
   :members:
   :undoc-members:
   :show-inheritance:
