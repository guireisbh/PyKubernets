kubernetes.client.models.v1\_job\_status module
===============================================

.. automodule:: kubernetes.client.models.v1_job_status
   :members:
   :undoc-members:
   :show-inheritance:
