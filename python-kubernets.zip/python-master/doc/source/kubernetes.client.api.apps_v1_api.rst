kubernetes.client.api.apps\_v1\_api module
==========================================

.. automodule:: kubernetes.client.api.apps_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
