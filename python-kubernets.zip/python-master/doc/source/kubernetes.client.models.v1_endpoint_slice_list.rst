kubernetes.client.models.v1\_endpoint\_slice\_list module
=========================================================

.. automodule:: kubernetes.client.models.v1_endpoint_slice_list
   :members:
   :undoc-members:
   :show-inheritance:
