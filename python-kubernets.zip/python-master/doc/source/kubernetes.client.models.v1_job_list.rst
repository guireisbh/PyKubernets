kubernetes.client.models.v1\_job\_list module
=============================================

.. automodule:: kubernetes.client.models.v1_job_list
   :members:
   :undoc-members:
   :show-inheritance:
