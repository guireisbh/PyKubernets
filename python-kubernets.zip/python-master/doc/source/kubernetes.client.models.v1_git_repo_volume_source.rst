kubernetes.client.models.v1\_git\_repo\_volume\_source module
=============================================================

.. automodule:: kubernetes.client.models.v1_git_repo_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
