kubernetes.client.api.core\_api module
======================================

.. automodule:: kubernetes.client.api.core_api
   :members:
   :undoc-members:
   :show-inheritance:
