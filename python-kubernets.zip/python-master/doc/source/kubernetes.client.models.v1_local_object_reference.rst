kubernetes.client.models.v1\_local\_object\_reference module
============================================================

.. automodule:: kubernetes.client.models.v1_local_object_reference
   :members:
   :undoc-members:
   :show-inheritance:
