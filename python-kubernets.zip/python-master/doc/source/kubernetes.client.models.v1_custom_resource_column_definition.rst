kubernetes.client.models.v1\_custom\_resource\_column\_definition module
========================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_column_definition
   :members:
   :undoc-members:
   :show-inheritance:
