kubernetes.client.models.v1\_pod\_affinity module
=================================================

.. automodule:: kubernetes.client.models.v1_pod_affinity
   :members:
   :undoc-members:
   :show-inheritance:
