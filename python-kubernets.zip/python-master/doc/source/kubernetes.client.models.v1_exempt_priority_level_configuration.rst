kubernetes.client.models.v1\_exempt\_priority\_level\_configuration module
==========================================================================

.. automodule:: kubernetes.client.models.v1_exempt_priority_level_configuration
   :members:
   :undoc-members:
   :show-inheritance:
