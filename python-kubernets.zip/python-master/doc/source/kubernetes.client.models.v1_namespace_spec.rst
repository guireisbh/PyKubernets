kubernetes.client.models.v1\_namespace\_spec module
===================================================

.. automodule:: kubernetes.client.models.v1_namespace_spec
   :members:
   :undoc-members:
   :show-inheritance:
