kubernetes.client.models.v1\_downward\_api\_projection module
=============================================================

.. automodule:: kubernetes.client.models.v1_downward_api_projection
   :members:
   :undoc-members:
   :show-inheritance:
