kubernetes.client.models.v1\_pod\_failure\_policy\_on\_pod\_conditions\_pattern module
======================================================================================

.. automodule:: kubernetes.client.models.v1_pod_failure_policy_on_pod_conditions_pattern
   :members:
   :undoc-members:
   :show-inheritance:
