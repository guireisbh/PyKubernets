kubernetes.client.models.v1\_api\_service\_list module
======================================================

.. automodule:: kubernetes.client.models.v1_api_service_list
   :members:
   :undoc-members:
   :show-inheritance:
