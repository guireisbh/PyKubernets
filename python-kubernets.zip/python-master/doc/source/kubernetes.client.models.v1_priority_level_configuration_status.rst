kubernetes.client.models.v1\_priority\_level\_configuration\_status module
==========================================================================

.. automodule:: kubernetes.client.models.v1_priority_level_configuration_status
   :members:
   :undoc-members:
   :show-inheritance:
