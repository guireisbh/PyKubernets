kubernetes.client.models.v1\_stateful\_set\_list module
=======================================================

.. automodule:: kubernetes.client.models.v1_stateful_set_list
   :members:
   :undoc-members:
   :show-inheritance:
