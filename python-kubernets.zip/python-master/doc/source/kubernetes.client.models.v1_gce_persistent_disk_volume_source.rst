kubernetes.client.models.v1\_gce\_persistent\_disk\_volume\_source module
=========================================================================

.. automodule:: kubernetes.client.models.v1_gce_persistent_disk_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
