kubernetes.client.api.admissionregistration\_api module
=======================================================

.. automodule:: kubernetes.client.api.admissionregistration_api
   :members:
   :undoc-members:
   :show-inheritance:
