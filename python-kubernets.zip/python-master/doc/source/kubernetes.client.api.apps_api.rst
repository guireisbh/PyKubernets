kubernetes.client.api.apps\_api module
======================================

.. automodule:: kubernetes.client.api.apps_api
   :members:
   :undoc-members:
   :show-inheritance:
