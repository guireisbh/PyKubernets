kubernetes.client.models.v1\_pod\_failure\_policy module
========================================================

.. automodule:: kubernetes.client.models.v1_pod_failure_policy
   :members:
   :undoc-members:
   :show-inheritance:
