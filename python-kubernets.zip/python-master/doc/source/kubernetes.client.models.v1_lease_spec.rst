kubernetes.client.models.v1\_lease\_spec module
===============================================

.. automodule:: kubernetes.client.models.v1_lease_spec
   :members:
   :undoc-members:
   :show-inheritance:
