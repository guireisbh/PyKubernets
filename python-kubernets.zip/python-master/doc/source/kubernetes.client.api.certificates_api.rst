kubernetes.client.api.certificates\_api module
==============================================

.. automodule:: kubernetes.client.api.certificates_api
   :members:
   :undoc-members:
   :show-inheritance:
