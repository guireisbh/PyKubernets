kubernetes.client.models.v1\_sleep\_action module
=================================================

.. automodule:: kubernetes.client.models.v1_sleep_action
   :members:
   :undoc-members:
   :show-inheritance:
