kubernetes.client.models.v1\_lease module
=========================================

.. automodule:: kubernetes.client.models.v1_lease
   :members:
   :undoc-members:
   :show-inheritance:
