kubernetes.client.models.v1\_api\_resource\_list module
=======================================================

.. automodule:: kubernetes.client.models.v1_api_resource_list
   :members:
   :undoc-members:
   :show-inheritance:
