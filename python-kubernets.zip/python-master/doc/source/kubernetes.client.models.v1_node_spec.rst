kubernetes.client.models.v1\_node\_spec module
==============================================

.. automodule:: kubernetes.client.models.v1_node_spec
   :members:
   :undoc-members:
   :show-inheritance:
