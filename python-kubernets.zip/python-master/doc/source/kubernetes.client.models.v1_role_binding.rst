kubernetes.client.models.v1\_role\_binding module
=================================================

.. automodule:: kubernetes.client.models.v1_role_binding
   :members:
   :undoc-members:
   :show-inheritance:
