kubernetes.client.models.v1\_service\_account\_subject module
=============================================================

.. automodule:: kubernetes.client.models.v1_service_account_subject
   :members:
   :undoc-members:
   :show-inheritance:
