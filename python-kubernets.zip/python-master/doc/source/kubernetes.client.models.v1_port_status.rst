kubernetes.client.models.v1\_port\_status module
================================================

.. automodule:: kubernetes.client.models.v1_port_status
   :members:
   :undoc-members:
   :show-inheritance:
