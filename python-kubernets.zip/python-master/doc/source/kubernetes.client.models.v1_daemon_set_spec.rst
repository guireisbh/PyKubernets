kubernetes.client.models.v1\_daemon\_set\_spec module
=====================================================

.. automodule:: kubernetes.client.models.v1_daemon_set_spec
   :members:
   :undoc-members:
   :show-inheritance:
