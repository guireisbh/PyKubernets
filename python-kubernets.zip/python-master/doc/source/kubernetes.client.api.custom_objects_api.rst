kubernetes.client.api.custom\_objects\_api module
=================================================

.. automodule:: kubernetes.client.api.custom_objects_api
   :members:
   :undoc-members:
   :show-inheritance:
