kubernetes.client.models.v1\_ingress\_class\_spec module
========================================================

.. automodule:: kubernetes.client.models.v1_ingress_class_spec
   :members:
   :undoc-members:
   :show-inheritance:
