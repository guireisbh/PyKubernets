kubernetes.client.models.v1\_node\_selector module
==================================================

.. automodule:: kubernetes.client.models.v1_node_selector
   :members:
   :undoc-members:
   :show-inheritance:
