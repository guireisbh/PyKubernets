kubernetes.client.models.v1\_pod\_disruption\_budget\_list module
=================================================================

.. automodule:: kubernetes.client.models.v1_pod_disruption_budget_list
   :members:
   :undoc-members:
   :show-inheritance:
