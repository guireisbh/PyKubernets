kubernetes.client.models.v1\_endpoint\_slice module
===================================================

.. automodule:: kubernetes.client.models.v1_endpoint_slice
   :members:
   :undoc-members:
   :show-inheritance:
