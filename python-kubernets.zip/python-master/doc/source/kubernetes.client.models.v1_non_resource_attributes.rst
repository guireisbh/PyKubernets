kubernetes.client.models.v1\_non\_resource\_attributes module
=============================================================

.. automodule:: kubernetes.client.models.v1_non_resource_attributes
   :members:
   :undoc-members:
   :show-inheritance:
