kubernetes.client.models.v1\_custom\_resource\_definition\_version module
=========================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_definition_version
   :members:
   :undoc-members:
   :show-inheritance:
