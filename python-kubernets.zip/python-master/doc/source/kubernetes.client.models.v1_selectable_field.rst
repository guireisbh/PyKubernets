kubernetes.client.models.v1\_selectable\_field module
=====================================================

.. automodule:: kubernetes.client.models.v1_selectable_field
   :members:
   :undoc-members:
   :show-inheritance:
