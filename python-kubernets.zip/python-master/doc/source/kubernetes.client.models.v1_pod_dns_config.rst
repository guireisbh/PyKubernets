kubernetes.client.models.v1\_pod\_dns\_config module
====================================================

.. automodule:: kubernetes.client.models.v1_pod_dns_config
   :members:
   :undoc-members:
   :show-inheritance:
