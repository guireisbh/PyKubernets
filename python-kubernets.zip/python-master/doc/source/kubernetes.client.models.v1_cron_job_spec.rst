kubernetes.client.models.v1\_cron\_job\_spec module
===================================================

.. automodule:: kubernetes.client.models.v1_cron_job_spec
   :members:
   :undoc-members:
   :show-inheritance:
