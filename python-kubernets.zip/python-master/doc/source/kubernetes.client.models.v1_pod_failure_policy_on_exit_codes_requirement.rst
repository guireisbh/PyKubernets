kubernetes.client.models.v1\_pod\_failure\_policy\_on\_exit\_codes\_requirement module
======================================================================================

.. automodule:: kubernetes.client.models.v1_pod_failure_policy_on_exit_codes_requirement
   :members:
   :undoc-members:
   :show-inheritance:
