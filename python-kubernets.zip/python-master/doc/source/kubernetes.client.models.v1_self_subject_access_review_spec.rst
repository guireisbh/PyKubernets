kubernetes.client.models.v1\_self\_subject\_access\_review\_spec module
=======================================================================

.. automodule:: kubernetes.client.models.v1_self_subject_access_review_spec
   :members:
   :undoc-members:
   :show-inheritance:
