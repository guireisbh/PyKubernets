kubernetes.client.models.v1\_pod\_ip module
===========================================

.. automodule:: kubernetes.client.models.v1_pod_ip
   :members:
   :undoc-members:
   :show-inheritance:
