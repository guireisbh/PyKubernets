kubernetes.client.models.v1\_resource\_quota module
===================================================

.. automodule:: kubernetes.client.models.v1_resource_quota
   :members:
   :undoc-members:
   :show-inheritance:
