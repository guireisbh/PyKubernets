kubernetes.client.models.v1\_api\_versions module
=================================================

.. automodule:: kubernetes.client.models.v1_api_versions
   :members:
   :undoc-members:
   :show-inheritance:
