kubernetes.client.models.v1\_resource\_attributes module
========================================================

.. automodule:: kubernetes.client.models.v1_resource_attributes
   :members:
   :undoc-members:
   :show-inheritance:
