kubernetes.client.models.v1\_ingress\_tls module
================================================

.. automodule:: kubernetes.client.models.v1_ingress_tls
   :members:
   :undoc-members:
   :show-inheritance:
