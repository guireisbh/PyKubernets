kubernetes.client.models.v1\_deployment\_status module
======================================================

.. automodule:: kubernetes.client.models.v1_deployment_status
   :members:
   :undoc-members:
   :show-inheritance:
