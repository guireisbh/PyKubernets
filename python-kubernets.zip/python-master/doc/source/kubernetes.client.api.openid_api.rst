kubernetes.client.api.openid\_api module
========================================

.. automodule:: kubernetes.client.api.openid_api
   :members:
   :undoc-members:
   :show-inheritance:
