kubernetes.client.api.autoscaling\_v2\_api module
=================================================

.. automodule:: kubernetes.client.api.autoscaling_v2_api
   :members:
   :undoc-members:
   :show-inheritance:
