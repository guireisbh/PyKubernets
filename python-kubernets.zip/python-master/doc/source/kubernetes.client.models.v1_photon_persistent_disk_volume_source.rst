kubernetes.client.models.v1\_photon\_persistent\_disk\_volume\_source module
============================================================================

.. automodule:: kubernetes.client.models.v1_photon_persistent_disk_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
