kubernetes.client.models.v1\_ingress\_status module
===================================================

.. automodule:: kubernetes.client.models.v1_ingress_status
   :members:
   :undoc-members:
   :show-inheritance:
