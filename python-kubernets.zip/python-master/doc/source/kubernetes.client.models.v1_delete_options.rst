kubernetes.client.models.v1\_delete\_options module
===================================================

.. automodule:: kubernetes.client.models.v1_delete_options
   :members:
   :undoc-members:
   :show-inheritance:
