kubernetes.client.models.v1\_api\_service\_spec module
======================================================

.. automodule:: kubernetes.client.models.v1_api_service_spec
   :members:
   :undoc-members:
   :show-inheritance:
