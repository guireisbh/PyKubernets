kubernetes.client.models.v1\_rolling\_update\_deployment module
===============================================================

.. automodule:: kubernetes.client.models.v1_rolling_update_deployment
   :members:
   :undoc-members:
   :show-inheritance:
