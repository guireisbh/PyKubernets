kubernetes.client.models.v1\_pod\_resource\_claim\_status module
================================================================

.. automodule:: kubernetes.client.models.v1_pod_resource_claim_status
   :members:
   :undoc-members:
   :show-inheritance:
