kubernetes.client.models.v1\_named\_rule\_with\_operations module
=================================================================

.. automodule:: kubernetes.client.models.v1_named_rule_with_operations
   :members:
   :undoc-members:
   :show-inheritance:
