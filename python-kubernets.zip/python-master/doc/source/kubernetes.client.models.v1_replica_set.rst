kubernetes.client.models.v1\_replica\_set module
================================================

.. automodule:: kubernetes.client.models.v1_replica_set
   :members:
   :undoc-members:
   :show-inheritance:
