kubernetes.client.api.core\_v1\_api module
==========================================

.. automodule:: kubernetes.client.api.core_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
