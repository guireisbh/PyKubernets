kubernetes.client.models.v1\_attached\_volume module
====================================================

.. automodule:: kubernetes.client.models.v1_attached_volume
   :members:
   :undoc-members:
   :show-inheritance:
