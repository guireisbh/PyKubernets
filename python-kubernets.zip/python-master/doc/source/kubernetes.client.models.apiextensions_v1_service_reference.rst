kubernetes.client.models.apiextensions\_v1\_service\_reference module
=====================================================================

.. automodule:: kubernetes.client.models.apiextensions_v1_service_reference
   :members:
   :undoc-members:
   :show-inheritance:
