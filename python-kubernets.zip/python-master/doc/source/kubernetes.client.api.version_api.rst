kubernetes.client.api.version\_api module
=========================================

.. automodule:: kubernetes.client.api.version_api
   :members:
   :undoc-members:
   :show-inheritance:
