kubernetes.client.models.v1\_rbd\_persistent\_volume\_source module
===================================================================

.. automodule:: kubernetes.client.models.v1_rbd_persistent_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
