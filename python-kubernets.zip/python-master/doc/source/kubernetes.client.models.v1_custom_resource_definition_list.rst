kubernetes.client.models.v1\_custom\_resource\_definition\_list module
======================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_definition_list
   :members:
   :undoc-members:
   :show-inheritance:
