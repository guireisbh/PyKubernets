kubernetes.client.models.v1\_stateful\_set\_condition module
============================================================

.. automodule:: kubernetes.client.models.v1_stateful_set_condition
   :members:
   :undoc-members:
   :show-inheritance:
