kubernetes.client.models.v1\_pod\_resource\_claim module
========================================================

.. automodule:: kubernetes.client.models.v1_pod_resource_claim
   :members:
   :undoc-members:
   :show-inheritance:
