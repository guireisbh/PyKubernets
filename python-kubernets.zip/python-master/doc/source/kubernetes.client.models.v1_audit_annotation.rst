kubernetes.client.models.v1\_audit\_annotation module
=====================================================

.. automodule:: kubernetes.client.models.v1_audit_annotation
   :members:
   :undoc-members:
   :show-inheritance:
