kubernetes.client.models.v1\_network\_policy\_peer module
=========================================================

.. automodule:: kubernetes.client.models.v1_network_policy_peer
   :members:
   :undoc-members:
   :show-inheritance:
