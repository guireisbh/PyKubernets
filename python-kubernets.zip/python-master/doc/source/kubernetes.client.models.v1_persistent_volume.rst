kubernetes.client.models.v1\_persistent\_volume module
======================================================

.. automodule:: kubernetes.client.models.v1_persistent_volume
   :members:
   :undoc-members:
   :show-inheritance:
