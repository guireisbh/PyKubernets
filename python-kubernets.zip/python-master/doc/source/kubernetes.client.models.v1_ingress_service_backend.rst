kubernetes.client.models.v1\_ingress\_service\_backend module
=============================================================

.. automodule:: kubernetes.client.models.v1_ingress_service_backend
   :members:
   :undoc-members:
   :show-inheritance:
