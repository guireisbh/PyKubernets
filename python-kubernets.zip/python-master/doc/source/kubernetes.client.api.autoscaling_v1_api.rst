kubernetes.client.api.autoscaling\_v1\_api module
=================================================

.. automodule:: kubernetes.client.api.autoscaling_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
