kubernetes.client.models.v1\_scale module
=========================================

.. automodule:: kubernetes.client.models.v1_scale
   :members:
   :undoc-members:
   :show-inheritance:
