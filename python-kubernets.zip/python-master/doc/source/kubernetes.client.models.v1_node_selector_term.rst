kubernetes.client.models.v1\_node\_selector\_term module
========================================================

.. automodule:: kubernetes.client.models.v1_node_selector_term
   :members:
   :undoc-members:
   :show-inheritance:
