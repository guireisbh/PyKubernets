kubernetes.client.models.v1\_stateful\_set\_update\_strategy module
===================================================================

.. automodule:: kubernetes.client.models.v1_stateful_set_update_strategy
   :members:
   :undoc-members:
   :show-inheritance:
