kubernetes.client.models.v1\_horizontal\_pod\_autoscaler\_spec module
=====================================================================

.. automodule:: kubernetes.client.models.v1_horizontal_pod_autoscaler_spec
   :members:
   :undoc-members:
   :show-inheritance:
