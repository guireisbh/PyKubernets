kubernetes.client.models.events\_v1\_event\_series module
=========================================================

.. automodule:: kubernetes.client.models.events_v1_event_series
   :members:
   :undoc-members:
   :show-inheritance:
