kubernetes.client.models.v1\_csi\_storage\_capacity\_list module
================================================================

.. automodule:: kubernetes.client.models.v1_csi_storage_capacity_list
   :members:
   :undoc-members:
   :show-inheritance:
