kubernetes.client.models.v1\_stateful\_set\_persistent\_volume\_claim\_retention\_policy module
===============================================================================================

.. automodule:: kubernetes.client.models.v1_stateful_set_persistent_volume_claim_retention_policy
   :members:
   :undoc-members:
   :show-inheritance:
