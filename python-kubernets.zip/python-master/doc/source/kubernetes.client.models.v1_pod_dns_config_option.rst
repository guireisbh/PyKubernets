kubernetes.client.models.v1\_pod\_dns\_config\_option module
============================================================

.. automodule:: kubernetes.client.models.v1_pod_dns_config_option
   :members:
   :undoc-members:
   :show-inheritance:
