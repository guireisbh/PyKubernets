kubernetes.client.models.admissionregistration\_v1\_service\_reference module
=============================================================================

.. automodule:: kubernetes.client.models.admissionregistration_v1_service_reference
   :members:
   :undoc-members:
   :show-inheritance:
