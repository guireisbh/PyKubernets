kubernetes.client.models.v1\_daemon\_set\_condition module
==========================================================

.. automodule:: kubernetes.client.models.v1_daemon_set_condition
   :members:
   :undoc-members:
   :show-inheritance:
