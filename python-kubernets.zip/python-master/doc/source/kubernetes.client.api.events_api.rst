kubernetes.client.api.events\_api module
========================================

.. automodule:: kubernetes.client.api.events_api
   :members:
   :undoc-members:
   :show-inheritance:
