kubernetes.client.models.v1\_object\_reference module
=====================================================

.. automodule:: kubernetes.client.models.v1_object_reference
   :members:
   :undoc-members:
   :show-inheritance:
