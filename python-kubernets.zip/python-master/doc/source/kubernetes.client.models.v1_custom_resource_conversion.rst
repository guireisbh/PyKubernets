kubernetes.client.models.v1\_custom\_resource\_conversion module
================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_conversion
   :members:
   :undoc-members:
   :show-inheritance:
