kubernetes.client.models.v1\_http\_ingress\_path module
=======================================================

.. automodule:: kubernetes.client.models.v1_http_ingress_path
   :members:
   :undoc-members:
   :show-inheritance:
