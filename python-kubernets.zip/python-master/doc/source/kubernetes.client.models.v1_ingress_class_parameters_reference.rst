kubernetes.client.models.v1\_ingress\_class\_parameters\_reference module
=========================================================================

.. automodule:: kubernetes.client.models.v1_ingress_class_parameters_reference
   :members:
   :undoc-members:
   :show-inheritance:
