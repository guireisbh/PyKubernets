kubernetes.client.models.v1\_session\_affinity\_config module
=============================================================

.. automodule:: kubernetes.client.models.v1_session_affinity_config
   :members:
   :undoc-members:
   :show-inheritance:
