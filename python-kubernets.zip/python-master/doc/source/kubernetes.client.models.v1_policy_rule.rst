kubernetes.client.models.v1\_policy\_rule module
================================================

.. automodule:: kubernetes.client.models.v1_policy_rule
   :members:
   :undoc-members:
   :show-inheritance:
