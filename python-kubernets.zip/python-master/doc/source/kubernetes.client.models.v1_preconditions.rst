kubernetes.client.models.v1\_preconditions module
=================================================

.. automodule:: kubernetes.client.models.v1_preconditions
   :members:
   :undoc-members:
   :show-inheritance:
