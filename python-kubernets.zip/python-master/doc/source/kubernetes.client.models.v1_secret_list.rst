kubernetes.client.models.v1\_secret\_list module
================================================

.. automodule:: kubernetes.client.models.v1_secret_list
   :members:
   :undoc-members:
   :show-inheritance:
