kubernetes.client.api.events\_v1\_api module
============================================

.. automodule:: kubernetes.client.api.events_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
