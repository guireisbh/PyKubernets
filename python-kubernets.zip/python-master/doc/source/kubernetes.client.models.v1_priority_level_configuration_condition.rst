kubernetes.client.models.v1\_priority\_level\_configuration\_condition module
=============================================================================

.. automodule:: kubernetes.client.models.v1_priority_level_configuration_condition
   :members:
   :undoc-members:
   :show-inheritance:
