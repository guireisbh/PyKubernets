kubernetes.client.models.v1\_namespace module
=============================================

.. automodule:: kubernetes.client.models.v1_namespace
   :members:
   :undoc-members:
   :show-inheritance:
