kubernetes.client.models.v1\_group\_version\_for\_discovery module
==================================================================

.. automodule:: kubernetes.client.models.v1_group_version_for_discovery
   :members:
   :undoc-members:
   :show-inheritance:
