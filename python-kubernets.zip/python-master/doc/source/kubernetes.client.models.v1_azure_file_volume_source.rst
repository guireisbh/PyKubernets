kubernetes.client.models.v1\_azure\_file\_volume\_source module
===============================================================

.. automodule:: kubernetes.client.models.v1_azure_file_volume_source
   :members:
   :undoc-members:
   :show-inheritance:
