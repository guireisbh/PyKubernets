kubernetes.client.models.v1\_queuing\_configuration module
==========================================================

.. automodule:: kubernetes.client.models.v1_queuing_configuration
   :members:
   :undoc-members:
   :show-inheritance:
