kubernetes.client.models.v1\_non\_resource\_policy\_rule module
===============================================================

.. automodule:: kubernetes.client.models.v1_non_resource_policy_rule
   :members:
   :undoc-members:
   :show-inheritance:
