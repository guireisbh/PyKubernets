kubernetes.client.models.v1\_node\_affinity module
==================================================

.. automodule:: kubernetes.client.models.v1_node_affinity
   :members:
   :undoc-members:
   :show-inheritance:
