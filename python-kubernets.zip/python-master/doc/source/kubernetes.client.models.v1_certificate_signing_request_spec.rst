kubernetes.client.models.v1\_certificate\_signing\_request\_spec module
=======================================================================

.. automodule:: kubernetes.client.models.v1_certificate_signing_request_spec
   :members:
   :undoc-members:
   :show-inheritance:
