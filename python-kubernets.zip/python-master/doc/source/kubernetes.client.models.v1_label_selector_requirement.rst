kubernetes.client.models.v1\_label\_selector\_requirement module
================================================================

.. automodule:: kubernetes.client.models.v1_label_selector_requirement
   :members:
   :undoc-members:
   :show-inheritance:
