kubernetes.client.models.core\_v1\_endpoint\_port module
========================================================

.. automodule:: kubernetes.client.models.core_v1_endpoint_port
   :members:
   :undoc-members:
   :show-inheritance:
