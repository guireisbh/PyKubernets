kubernetes.client.models.v1\_priority\_level\_configuration\_reference module
=============================================================================

.. automodule:: kubernetes.client.models.v1_priority_level_configuration_reference
   :members:
   :undoc-members:
   :show-inheritance:
