kubernetes.client.models.v1\_pod\_template module
=================================================

.. automodule:: kubernetes.client.models.v1_pod_template
   :members:
   :undoc-members:
   :show-inheritance:
