kubernetes.client.models.v1\_flow\_schema\_spec module
======================================================

.. automodule:: kubernetes.client.models.v1_flow_schema_spec
   :members:
   :undoc-members:
   :show-inheritance:
