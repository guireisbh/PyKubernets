kubernetes.client.models.events\_v1\_event module
=================================================

.. automodule:: kubernetes.client.models.events_v1_event
   :members:
   :undoc-members:
   :show-inheritance:
