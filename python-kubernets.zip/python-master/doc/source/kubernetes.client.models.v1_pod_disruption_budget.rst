kubernetes.client.models.v1\_pod\_disruption\_budget module
===========================================================

.. automodule:: kubernetes.client.models.v1_pod_disruption_budget
   :members:
   :undoc-members:
   :show-inheritance:
