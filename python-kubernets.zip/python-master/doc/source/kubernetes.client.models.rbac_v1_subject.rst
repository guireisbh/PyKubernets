kubernetes.client.models.rbac\_v1\_subject module
=================================================

.. automodule:: kubernetes.client.models.rbac_v1_subject
   :members:
   :undoc-members:
   :show-inheritance:
