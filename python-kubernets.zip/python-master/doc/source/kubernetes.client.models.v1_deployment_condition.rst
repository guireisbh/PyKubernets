kubernetes.client.models.v1\_deployment\_condition module
=========================================================

.. automodule:: kubernetes.client.models.v1_deployment_condition
   :members:
   :undoc-members:
   :show-inheritance:
