kubernetes.client.models.v1\_http\_get\_action module
=====================================================

.. automodule:: kubernetes.client.models.v1_http_get_action
   :members:
   :undoc-members:
   :show-inheritance:
