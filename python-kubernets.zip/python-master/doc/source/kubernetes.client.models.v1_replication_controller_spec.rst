kubernetes.client.models.v1\_replication\_controller\_spec module
=================================================================

.. automodule:: kubernetes.client.models.v1_replication_controller_spec
   :members:
   :undoc-members:
   :show-inheritance:
