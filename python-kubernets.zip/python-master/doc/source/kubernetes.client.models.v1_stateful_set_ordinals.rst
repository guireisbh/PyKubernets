kubernetes.client.models.v1\_stateful\_set\_ordinals module
===========================================================

.. automodule:: kubernetes.client.models.v1_stateful_set_ordinals
   :members:
   :undoc-members:
   :show-inheritance:
