kubernetes.client.api.apiregistration\_api module
=================================================

.. automodule:: kubernetes.client.api.apiregistration_api
   :members:
   :undoc-members:
   :show-inheritance:
