kubernetes.client.models.v1\_pod\_anti\_affinity module
=======================================================

.. automodule:: kubernetes.client.models.v1_pod_anti_affinity
   :members:
   :undoc-members:
   :show-inheritance:
