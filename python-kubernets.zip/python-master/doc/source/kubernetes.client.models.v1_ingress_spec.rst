kubernetes.client.models.v1\_ingress\_spec module
=================================================

.. automodule:: kubernetes.client.models.v1_ingress_spec
   :members:
   :undoc-members:
   :show-inheritance:
