kubernetes.client.models.v1\_external\_documentation module
===========================================================

.. automodule:: kubernetes.client.models.v1_external_documentation
   :members:
   :undoc-members:
   :show-inheritance:
