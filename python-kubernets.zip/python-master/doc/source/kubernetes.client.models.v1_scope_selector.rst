kubernetes.client.models.v1\_scope\_selector module
===================================================

.. automodule:: kubernetes.client.models.v1_scope_selector
   :members:
   :undoc-members:
   :show-inheritance:
