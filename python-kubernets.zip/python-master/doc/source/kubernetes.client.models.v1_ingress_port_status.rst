kubernetes.client.models.v1\_ingress\_port\_status module
=========================================================

.. automodule:: kubernetes.client.models.v1_ingress_port_status
   :members:
   :undoc-members:
   :show-inheritance:
