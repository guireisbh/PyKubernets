kubernetes.client.api.admissionregistration\_v1\_api module
===========================================================

.. automodule:: kubernetes.client.api.admissionregistration_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
