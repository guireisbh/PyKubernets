kubernetes.client.models.v1\_custom\_resource\_subresource\_scale module
========================================================================

.. automodule:: kubernetes.client.models.v1_custom_resource_subresource_scale
   :members:
   :undoc-members:
   :show-inheritance:
