kubernetes.client.models.v1\_json\_schema\_props module
=======================================================

.. automodule:: kubernetes.client.models.v1_json_schema_props
   :members:
   :undoc-members:
   :show-inheritance:
