kubernetes.client.api.storagemigration\_api module
==================================================

.. automodule:: kubernetes.client.api.storagemigration_api
   :members:
   :undoc-members:
   :show-inheritance:
