kubernetes.client.models.flowcontrol\_v1\_subject module
========================================================

.. automodule:: kubernetes.client.models.flowcontrol_v1_subject
   :members:
   :undoc-members:
   :show-inheritance:
