kubernetes.client.models.v1\_replica\_set\_spec module
======================================================

.. automodule:: kubernetes.client.models.v1_replica_set_spec
   :members:
   :undoc-members:
   :show-inheritance:
