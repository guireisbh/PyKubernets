kubernetes.client.models.apiextensions\_v1\_webhook\_client\_config module
==========================================================================

.. automodule:: kubernetes.client.models.apiextensions_v1_webhook_client_config
   :members:
   :undoc-members:
   :show-inheritance:
