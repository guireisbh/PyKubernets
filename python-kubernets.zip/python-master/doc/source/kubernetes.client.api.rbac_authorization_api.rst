kubernetes.client.api.rbac\_authorization\_api module
=====================================================

.. automodule:: kubernetes.client.api.rbac_authorization_api
   :members:
   :undoc-members:
   :show-inheritance:
