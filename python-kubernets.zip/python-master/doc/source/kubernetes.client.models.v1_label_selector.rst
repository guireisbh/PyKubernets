kubernetes.client.models.v1\_label\_selector module
===================================================

.. automodule:: kubernetes.client.models.v1_label_selector
   :members:
   :undoc-members:
   :show-inheritance:
