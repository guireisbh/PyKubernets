kubernetes.client.models.v1\_container\_resize\_policy module
=============================================================

.. automodule:: kubernetes.client.models.v1_container_resize_policy
   :members:
   :undoc-members:
   :show-inheritance:
