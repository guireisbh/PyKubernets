kubernetes.client.models.v1\_controller\_revision\_list module
==============================================================

.. automodule:: kubernetes.client.models.v1_controller_revision_list
   :members:
   :undoc-members:
   :show-inheritance:
