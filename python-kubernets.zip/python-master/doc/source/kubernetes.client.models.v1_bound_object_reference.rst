kubernetes.client.models.v1\_bound\_object\_reference module
============================================================

.. automodule:: kubernetes.client.models.v1_bound_object_reference
   :members:
   :undoc-members:
   :show-inheritance:
