kubernetes.client.models.v1\_self\_subject\_access\_review module
=================================================================

.. automodule:: kubernetes.client.models.v1_self_subject_access_review
   :members:
   :undoc-members:
   :show-inheritance:
