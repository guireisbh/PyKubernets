kubernetes.client.models.v1\_lease\_list module
===============================================

.. automodule:: kubernetes.client.models.v1_lease_list
   :members:
   :undoc-members:
   :show-inheritance:
