kubernetes.client.models.v1\_scheduling module
==============================================

.. automodule:: kubernetes.client.models.v1_scheduling
   :members:
   :undoc-members:
   :show-inheritance:
