kubernetes.client.models.v1\_resource\_requirements module
==========================================================

.. automodule:: kubernetes.client.models.v1_resource_requirements
   :members:
   :undoc-members:
   :show-inheritance:
