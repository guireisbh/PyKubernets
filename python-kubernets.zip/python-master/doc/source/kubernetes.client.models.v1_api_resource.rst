kubernetes.client.models.v1\_api\_resource module
=================================================

.. automodule:: kubernetes.client.models.v1_api_resource
   :members:
   :undoc-members:
   :show-inheritance:
