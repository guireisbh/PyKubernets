kubernetes.client.api.rbac\_authorization\_v1\_api module
=========================================================

.. automodule:: kubernetes.client.api.rbac_authorization_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
