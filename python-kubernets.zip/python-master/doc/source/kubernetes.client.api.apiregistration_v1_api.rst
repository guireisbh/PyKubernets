kubernetes.client.api.apiregistration\_v1\_api module
=====================================================

.. automodule:: kubernetes.client.api.apiregistration_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
