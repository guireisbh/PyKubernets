kubernetes.client.models.v1\_limit\_range\_spec module
======================================================

.. automodule:: kubernetes.client.models.v1_limit_range_spec
   :members:
   :undoc-members:
   :show-inheritance:
