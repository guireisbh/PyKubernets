kubernetes.client.models.v1\_config\_map\_key\_selector module
==============================================================

.. automodule:: kubernetes.client.models.v1_config_map_key_selector
   :members:
   :undoc-members:
   :show-inheritance:
