kubernetes.client.models.v1\_network\_policy module
===================================================

.. automodule:: kubernetes.client.models.v1_network_policy
   :members:
   :undoc-members:
   :show-inheritance:
