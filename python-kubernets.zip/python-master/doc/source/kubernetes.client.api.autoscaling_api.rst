kubernetes.client.api.autoscaling\_api module
=============================================

.. automodule:: kubernetes.client.api.autoscaling_api
   :members:
   :undoc-members:
   :show-inheritance:
