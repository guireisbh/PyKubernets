kubernetes.client.models.v1\_resource\_quota\_spec module
=========================================================

.. automodule:: kubernetes.client.models.v1_resource_quota_spec
   :members:
   :undoc-members:
   :show-inheritance:
