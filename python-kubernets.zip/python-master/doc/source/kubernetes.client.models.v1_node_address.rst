kubernetes.client.models.v1\_node\_address module
=================================================

.. automodule:: kubernetes.client.models.v1_node_address
   :members:
   :undoc-members:
   :show-inheritance:
