kubernetes.client.models.v1\_secret module
==========================================

.. automodule:: kubernetes.client.models.v1_secret
   :members:
   :undoc-members:
   :show-inheritance:
