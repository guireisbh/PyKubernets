kubernetes.client.models.v1\_pod\_list module
=============================================

.. automodule:: kubernetes.client.models.v1_pod_list
   :members:
   :undoc-members:
   :show-inheritance:
