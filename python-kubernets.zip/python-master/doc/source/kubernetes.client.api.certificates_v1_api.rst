kubernetes.client.api.certificates\_v1\_api module
==================================================

.. automodule:: kubernetes.client.api.certificates_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
