kubernetes.client.api.batch\_api module
=======================================

.. automodule:: kubernetes.client.api.batch_api
   :members:
   :undoc-members:
   :show-inheritance:
