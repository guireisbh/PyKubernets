kubernetes.client.models.v1\_service\_list module
=================================================

.. automodule:: kubernetes.client.models.v1_service_list
   :members:
   :undoc-members:
   :show-inheritance:
