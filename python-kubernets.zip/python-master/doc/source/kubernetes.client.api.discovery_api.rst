kubernetes.client.api.discovery\_api module
===========================================

.. automodule:: kubernetes.client.api.discovery_api
   :members:
   :undoc-members:
   :show-inheritance:
