kubernetes.client.models.v1\_preferred\_scheduling\_term module
===============================================================

.. automodule:: kubernetes.client.models.v1_preferred_scheduling_term
   :members:
   :undoc-members:
   :show-inheritance:
