kubernetes.client.models.v1\_self\_subject\_rules\_review\_spec module
======================================================================

.. automodule:: kubernetes.client.models.v1_self_subject_rules_review_spec
   :members:
   :undoc-members:
   :show-inheritance:
