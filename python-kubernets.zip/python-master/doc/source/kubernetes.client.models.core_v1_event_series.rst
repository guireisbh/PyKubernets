kubernetes.client.models.core\_v1\_event\_series module
=======================================================

.. automodule:: kubernetes.client.models.core_v1_event_series
   :members:
   :undoc-members:
   :show-inheritance:
