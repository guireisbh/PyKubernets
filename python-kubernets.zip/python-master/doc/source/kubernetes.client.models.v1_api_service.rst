kubernetes.client.models.v1\_api\_service module
================================================

.. automodule:: kubernetes.client.models.v1_api_service
   :members:
   :undoc-members:
   :show-inheritance:
