kubernetes.client.api.authorization\_api module
===============================================

.. automodule:: kubernetes.client.api.authorization_api
   :members:
   :undoc-members:
   :show-inheritance:
