kubernetes.client.models.apiregistration\_v1\_service\_reference module
=======================================================================

.. automodule:: kubernetes.client.models.apiregistration_v1_service_reference
   :members:
   :undoc-members:
   :show-inheritance:
