kubernetes.client.models.v1\_daemon\_endpoint module
====================================================

.. automodule:: kubernetes.client.models.v1_daemon_endpoint
   :members:
   :undoc-members:
   :show-inheritance:
