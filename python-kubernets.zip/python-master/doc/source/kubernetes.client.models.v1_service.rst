kubernetes.client.models.v1\_service module
===========================================

.. automodule:: kubernetes.client.models.v1_service
   :members:
   :undoc-members:
   :show-inheritance:
