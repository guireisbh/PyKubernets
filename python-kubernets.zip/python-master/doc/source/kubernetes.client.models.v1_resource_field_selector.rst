kubernetes.client.models.v1\_resource\_field\_selector module
=============================================================

.. automodule:: kubernetes.client.models.v1_resource_field_selector
   :members:
   :undoc-members:
   :show-inheritance:
