kubernetes.client.models.v1\_flow\_schema module
================================================

.. automodule:: kubernetes.client.models.v1_flow_schema
   :members:
   :undoc-members:
   :show-inheritance:
