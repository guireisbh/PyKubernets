kubernetes.client.models.v1\_role module
========================================

.. automodule:: kubernetes.client.models.v1_role
   :members:
   :undoc-members:
   :show-inheritance:
