kubernetes.client.models.v1\_role\_ref module
=============================================

.. automodule:: kubernetes.client.models.v1_role_ref
   :members:
   :undoc-members:
   :show-inheritance:
