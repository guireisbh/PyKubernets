kubernetes.client.models.admissionregistration\_v1\_webhook\_client\_config module
==================================================================================

.. automodule:: kubernetes.client.models.admissionregistration_v1_webhook_client_config
   :members:
   :undoc-members:
   :show-inheritance:
