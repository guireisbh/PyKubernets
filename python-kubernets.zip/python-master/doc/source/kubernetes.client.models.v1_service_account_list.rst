kubernetes.client.models.v1\_service\_account\_list module
==========================================================

.. automodule:: kubernetes.client.models.v1_service_account_list
   :members:
   :undoc-members:
   :show-inheritance:
