kubernetes.client.models.v1\_daemon\_set module
===============================================

.. automodule:: kubernetes.client.models.v1_daemon_set
   :members:
   :undoc-members:
   :show-inheritance:
