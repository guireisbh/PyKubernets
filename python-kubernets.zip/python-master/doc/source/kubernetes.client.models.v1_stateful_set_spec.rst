kubernetes.client.models.v1\_stateful\_set\_spec module
=======================================================

.. automodule:: kubernetes.client.models.v1_stateful_set_spec
   :members:
   :undoc-members:
   :show-inheritance:
