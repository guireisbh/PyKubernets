kubernetes.client.models.v1\_endpoint module
============================================

.. automodule:: kubernetes.client.models.v1_endpoint
   :members:
   :undoc-members:
   :show-inheritance:
