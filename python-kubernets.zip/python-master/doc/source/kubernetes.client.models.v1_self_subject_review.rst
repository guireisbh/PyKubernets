kubernetes.client.models.v1\_self\_subject\_review module
=========================================================

.. automodule:: kubernetes.client.models.v1_self_subject_review
   :members:
   :undoc-members:
   :show-inheritance:
