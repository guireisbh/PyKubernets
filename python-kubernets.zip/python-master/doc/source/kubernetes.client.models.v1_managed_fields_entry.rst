kubernetes.client.models.v1\_managed\_fields\_entry module
==========================================================

.. automodule:: kubernetes.client.models.v1_managed_fields_entry
   :members:
   :undoc-members:
   :show-inheritance:
