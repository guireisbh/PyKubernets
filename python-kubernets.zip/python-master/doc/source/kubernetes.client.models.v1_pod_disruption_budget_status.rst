kubernetes.client.models.v1\_pod\_disruption\_budget\_status module
===================================================================

.. automodule:: kubernetes.client.models.v1_pod_disruption_budget_status
   :members:
   :undoc-members:
   :show-inheritance:
