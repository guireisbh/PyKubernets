kubernetes.client.models.v1\_scoped\_resource\_selector\_requirement module
===========================================================================

.. automodule:: kubernetes.client.models.v1_scoped_resource_selector_requirement
   :members:
   :undoc-members:
   :show-inheritance:
