kubernetes.client.api.resource\_api module
==========================================

.. automodule:: kubernetes.client.api.resource_api
   :members:
   :undoc-members:
   :show-inheritance:
