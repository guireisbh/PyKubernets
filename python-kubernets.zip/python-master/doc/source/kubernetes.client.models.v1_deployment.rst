kubernetes.client.models.v1\_deployment module
==============================================

.. automodule:: kubernetes.client.models.v1_deployment
   :members:
   :undoc-members:
   :show-inheritance:
