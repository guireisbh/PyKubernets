kubernetes.client.models.v1\_controller\_revision module
========================================================

.. automodule:: kubernetes.client.models.v1_controller_revision
   :members:
   :undoc-members:
   :show-inheritance:
