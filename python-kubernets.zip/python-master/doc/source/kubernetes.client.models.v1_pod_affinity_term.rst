kubernetes.client.models.v1\_pod\_affinity\_term module
=======================================================

.. automodule:: kubernetes.client.models.v1_pod_affinity_term
   :members:
   :undoc-members:
   :show-inheritance:
