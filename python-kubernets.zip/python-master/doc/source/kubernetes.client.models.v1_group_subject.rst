kubernetes.client.models.v1\_group\_subject module
==================================================

.. automodule:: kubernetes.client.models.v1_group_subject
   :members:
   :undoc-members:
   :show-inheritance:
