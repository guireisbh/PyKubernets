kubernetes.client.models.v1\_deployment\_strategy module
========================================================

.. automodule:: kubernetes.client.models.v1_deployment_strategy
   :members:
   :undoc-members:
   :show-inheritance:
