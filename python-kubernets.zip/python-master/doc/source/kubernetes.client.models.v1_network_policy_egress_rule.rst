kubernetes.client.models.v1\_network\_policy\_egress\_rule module
=================================================================

.. automodule:: kubernetes.client.models.v1_network_policy_egress_rule
   :members:
   :undoc-members:
   :show-inheritance:
