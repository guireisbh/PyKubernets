kubernetes.client.models.v1\_secret\_key\_selector module
=========================================================

.. automodule:: kubernetes.client.models.v1_secret_key_selector
   :members:
   :undoc-members:
   :show-inheritance:
