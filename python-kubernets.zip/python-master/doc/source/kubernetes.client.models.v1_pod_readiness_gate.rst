kubernetes.client.models.v1\_pod\_readiness\_gate module
========================================================

.. automodule:: kubernetes.client.models.v1_pod_readiness_gate
   :members:
   :undoc-members:
   :show-inheritance:
