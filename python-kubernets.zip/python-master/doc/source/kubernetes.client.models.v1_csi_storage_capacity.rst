kubernetes.client.models.v1\_csi\_storage\_capacity module
==========================================================

.. automodule:: kubernetes.client.models.v1_csi_storage_capacity
   :members:
   :undoc-members:
   :show-inheritance:
