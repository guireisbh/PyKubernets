kubernetes.client.models.v1\_pod\_os module
===========================================

.. automodule:: kubernetes.client.models.v1_pod_os
   :members:
   :undoc-members:
   :show-inheritance:
