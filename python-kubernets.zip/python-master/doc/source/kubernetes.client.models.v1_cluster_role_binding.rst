kubernetes.client.models.v1\_cluster\_role\_binding module
==========================================================

.. automodule:: kubernetes.client.models.v1_cluster_role_binding
   :members:
   :undoc-members:
   :show-inheritance:
