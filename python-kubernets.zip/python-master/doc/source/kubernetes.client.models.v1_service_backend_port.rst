kubernetes.client.models.v1\_service\_backend\_port module
==========================================================

.. automodule:: kubernetes.client.models.v1_service_backend_port
   :members:
   :undoc-members:
   :show-inheritance:
