kubernetes.client.api.batch\_v1\_api module
===========================================

.. automodule:: kubernetes.client.api.batch_v1_api
   :members:
   :undoc-members:
   :show-inheritance:
