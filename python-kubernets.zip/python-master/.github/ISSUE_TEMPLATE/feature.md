---
name: Feature request
about: Suggest a new feature for the project
labels: kind/feature

---

**What is the feature and why do you need it**:

**Describe the solution you'd like to see**:
